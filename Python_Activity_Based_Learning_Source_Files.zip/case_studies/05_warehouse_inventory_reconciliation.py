inventory = [
    ("Rice", 120, 80, 150, 50, 100),
    ("Oil", 60, 40, 55, 45, 60),
    ("Sugar", 90, 20, 30, 85, 100)
]

print("WAREHOUSE RECONCILIATION")
for name, opening, received, dispatched, recorded, target in inventory:
    expected = opening + received - dispatched
    discrepancy = recorded - expected
    replenishment = max(0, target - expected)
    status = "MATCH" if discrepancy == 0 else "MISMATCH"
    print(f"{name}: expected={expected}, recorded={recorded}, "
          f"variance={discrepancy} ({status}), replenish={replenishment}")\n