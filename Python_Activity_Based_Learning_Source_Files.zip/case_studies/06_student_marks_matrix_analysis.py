students = ["Anu", "Balu", "Chitra", "Deepak"]
subjects = ["Maths", "Python", "English"]
marks = [
    [78, 88, 75],
    [55, 62, 58],
    [92, 95, 90],
    [65, 70, 60]
]

totals = []
print("STUDENT PERFORMANCE")
for name, row in zip(students, marks):
    total = sum(row)
    average = total / len(row)
    totals.append(total)
    print(f"{name}: total={total}, average={average:.2f}")

print("SUBJECT AVERAGES")
for col, subject in enumerate(subjects):
    average = sum(row[col] for row in marks) / len(marks)
    status = "LOW" if average < 60 else "OK"
    print(f"{subject}: {average:.2f} ({status})")

top_index = totals.index(max(totals))
print("Top performer:", students[top_index])\n