menu = [
    ["Idli", 30.0, 20],
    ["Dosa", 50.0, 15],
    ["Juice", 25.0, 10]
]
orders = [("Idli", 2), ("Dosa", 3), ("Juice", 12),
          ("Samosa", 1), ("Idli", 1)]

daily_sales = 0.0
print("CANTEEN ORDER REPORT")

for item_name, quantity in orders:
    found = False
    for item in menu:
        name, price, stock = item
        if name == item_name:
            found = True
            if quantity <= 0:
                print(f"{item_name}: rejected - quantity must be positive")
            elif quantity > stock:
                print(f"{item_name}: rejected - only {stock} available")
            else:
                amount = price * quantity
                item[2] -= quantity
                daily_sales += amount
                print(f"{item_name} x {quantity}: accepted, Rs.{amount:.2f}")
            break
    if not found:
        print(f"{item_name}: rejected - item not on menu")

print(f"Daily sales: Rs.{daily_sales:.2f}")
print("Remaining stock:")
for name, price, stock in menu:
    print(f"{name}: {stock}")\n