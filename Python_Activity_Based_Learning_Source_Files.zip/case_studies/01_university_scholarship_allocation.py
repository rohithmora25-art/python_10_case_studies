applicants = [
    ("Asha", 88, 79, 91, 92, 180000),
    ("Bharat", 80, 82, 78, 85, 220000),
    ("Charan", 95, 58, 90, 95, 150000),
    ("Divya", 76, 78, 80, 72, 200000),
    ("Eshan", 85, 85, 85, 90, 300000)
]

eligible = []
not_eligible = []

for name, m1, m2, m3, attendance, income in applicants:
    average = (m1 + m2 + m3) / 3
    if (average >= 75 and min(m1, m2, m3) >= 60
            and attendance >= 75 and income <= 250000):
        eligible.append((name, average, attendance, income))
    else:
        not_eligible.append(name)

eligible.sort(key=lambda item: (-item[1], -item[2], item[3]))

print("SCHOLARSHIP RANK LIST")
for rank, (name, avg, attendance, income) in enumerate(eligible, 1):
    print(f"{rank}. {name}: {avg:.2f}% | Attendance: {attendance}% | Income: Rs.{income}")
print("Not eligible:", ", ".join(not_eligible))\n