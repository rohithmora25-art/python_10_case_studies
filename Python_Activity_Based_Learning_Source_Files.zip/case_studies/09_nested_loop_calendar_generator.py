month = "November 2026"
start_weekday = 6  # Sunday; Monday=0 ... Sunday=6
days_in_month = 30

if not (0 <= start_weekday <= 6 and 28 <= days_in_month <= 31):
    print("Invalid calendar input")
else:
    print(month.center(28))
    print("Mon Tue Wed Thu Fri Sat Sun")
    for _ in range(start_weekday):
        print("    ", end="")

    for day in range(1, days_in_month + 1):
        print(f"{day:>3} ", end="")
        if (start_weekday + day) % 7 == 0:
            print()
    if (start_weekday + days_in_month) % 7 != 0:
        print()\n