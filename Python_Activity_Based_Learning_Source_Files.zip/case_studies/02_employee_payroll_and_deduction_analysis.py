name = "Meera"
basic = 30000.0
overtime_hours = 8
incentive = 2500.0

hra = basic * 0.20
travel_allowance = basic * 0.10
hourly_rate = basic / 160
overtime_pay = hourly_rate * 1.5 * overtime_hours
gross = basic + hra + travel_allowance + overtime_pay + incentive

deduction = 0.0
if gross > 20000:
    deduction += (min(gross, 40000) - 20000) * 0.05
if gross > 40000:
    deduction += (gross - 40000) * 0.10

net_salary = gross - deduction

print("EMPLOYEE SALARY STATEMENT")
print("Employee:", name)
print(f"Basic Pay: Rs.{basic:.2f}")
print(f"HRA: Rs.{hra:.2f}")
print(f"Travel Allowance: Rs.{travel_allowance:.2f}")
print(f"Overtime Pay: Rs.{overtime_pay:.2f}")
print(f"Incentive: Rs.{incentive:.2f}")
print(f"Gross Salary: Rs.{gross:.2f}")
print(f"Deduction: Rs.{deduction:.2f}")
print(f"Net Salary: Rs.{net_salary:.2f}")\n