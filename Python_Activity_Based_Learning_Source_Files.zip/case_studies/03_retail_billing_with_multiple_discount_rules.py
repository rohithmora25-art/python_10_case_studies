items = [
    ("Notebook", "other", 80.0, 10),
    ("Snacks", "food", 50.0, 12),
    ("Pen Pack", "other", 120.0, 8)
]

subtotal = sum(price * qty for name, category, price, qty in items)
discount = min(subtotal * 0.10, 500) if subtotal >= 3000 else 0
discount_ratio = discount / subtotal if subtotal else 0

print("RETAIL INVOICE")
total_tax = 0.0
for name, category, price, qty in items:
    line = price * qty
    line_discount = line * discount_ratio
    taxable = line - line_discount
    rate = 0.05 if category == "food" else 0.12
    tax = taxable * rate
    total_tax += tax
    print(f"{name}: {qty} x Rs.{price:.2f} = Rs.{line:.2f}; tax Rs.{tax:.2f}")

payable = subtotal - discount + total_tax
print(f"Subtotal: Rs.{subtotal:.2f}")
print(f"Discount: Rs.{discount:.2f}")
print(f"Tax: Rs.{total_tax:.2f}")
print(f"Amount Payable: Rs.{payable:.2f}")\n