shifts = [
    ("Ravi", 9, 13),
    ("Mina", 10, 14),
    ("Ravi", 12, 16),
    ("Ravi", 16, 18),
    ("Mina", 15, 18)
]

conflicts = []
for i in range(len(shifts)):
    employee1, start1, end1 = shifts[i]
    if start1 >= end1:
        print("Invalid shift:", shifts[i])
        continue
    for j in range(i + 1, len(shifts)):
        employee2, start2, end2 = shifts[j]
        if start2 >= end2:
            continue
        if employee1 == employee2 and start1 < end2 and start2 < end1:
            conflicts.append((employee1, (start1, end1), (start2, end2)))

if conflicts:
    print("SHIFT CONFLICTS")
    for employee, first, second in conflicts:
        print(f"{employee}: {first[0]}-{first[1]} overlaps "
              f"{second[0]}-{second[1]}")
else:
    print("No conflicts found")\n