balance = 5000.0
transactions = [
    ("deposit", 2000),
    ("withdraw", 1500),
    ("withdraw", 7000),
    ("deposit", -100),
    ("balance", 0)
]

successful_count = 0
for action, amount in transactions:
    if action == "deposit":
        if amount > 0:
            balance += amount
            successful_count += 1
            print(f"Deposit accepted: Rs.{amount:.2f}")
        else:
            print("Deposit rejected: amount must be positive")
    elif action == "withdraw":
        if amount <= 0:
            print("Withdrawal rejected: amount must be positive")
        elif amount > 10000:
            print("Withdrawal rejected: limit is Rs.10000")
        elif amount > balance:
            print("Withdrawal rejected: insufficient balance")
        else:
            balance -= amount
            successful_count += 1
            print(f"Withdrawal accepted: Rs.{amount:.2f}")
    elif action == "balance":
        print(f"Current balance: Rs.{balance:.2f}")
    else:
        print("Invalid menu action")

print(f"Final balance: Rs.{balance:.2f}")
print("Successful transactions:", successful_count)\n