# Python Activity-Based Learning - 10 Case Studies

A beginner-level Python activity portfolio based on the uploaded assignment instructions.

## Repository description
Ten complete Python case studies covering computational thinking, algorithms, flowcharts, pseudocode, variables, data types, operators, conditions, loops, strings, lists, nested lists, tuples, tuple operations, and unpacking.

## Included case studies
1. University Scholarship Allocation
2. Employee Payroll and Deduction Analysis
3. Retail Billing with Multiple Discount Rules
4. ATM Menu-Driven Banking Simulation
5. Warehouse Inventory Reconciliation
6. Student Marks Matrix Analysis
7. Tuple-Based Employee Shift Conflict Detection
8. Text Compression Using Character Runs
9. Nested Loop Calendar Generator
10. Smart Canteen Order and Stock Management

## Files
- `Python_Activity_Based_Learning_10_Case_Studies.pdf` - combined assignment report.
- `case_studies/` - standalone Python source files for all ten exercises.

## Run a program
Use Python 3:
```bash
python 01_university_scholarship_allocation.py
```
Run the relevant file from the `case_studies` directory.

## Academic note
The assignment asks for output screenshots. This report includes reproducible sample console outputs; capture actual screenshots after running each program in your own Python IDE before final academic submission. Review the assumptions and replace sample data with any values specified by your faculty member.
