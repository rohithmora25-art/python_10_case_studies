text = "AAAABBBCCDAAAAA"

if text == "":
    encoded = ""
else:
    encoded_parts = []
    current = text[0]
    count = 1

    for char in text[1:]:
        if char == current:
            count += 1
        else:
            encoded_parts.append(current + str(count))
            current = char
            count = 1

    encoded_parts.append(current + str(count))
    encoded = "".join(encoded_parts)

result = encoded if len(encoded) < len(text) else text
print("Original:", text)
print("Encoded:", encoded)
print("Original length:", len(text))
print("Encoded length:", len(encoded))
print("Selected representation:", result)\n